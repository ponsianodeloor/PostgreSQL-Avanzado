Select 
prestamo_id,
libro_id,
coalesce(mora,0)
from prestamo_detalle